<?php
  class guests extends DB
  {
	var $table = "guests";	
  }
?>