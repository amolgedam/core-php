<?php

define('HTTP_DOMAIN','http://localhost/Animation_project/');
define('FTP_DOMAIN', 'E:/xampp/htdocs/Animation_project/');

require_once('models/db.php');
require_once('includes/database.php');

//session_start();
//session_name('Auth');
?>
