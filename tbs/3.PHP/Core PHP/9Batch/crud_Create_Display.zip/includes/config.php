<?php 
// Connection with Server
$conn = mysql_connect("localhost","root","") or die("could not connect with Server");


// Selection of Database
mysql_select_db("batch_25_crud",$conn) or die("could not connect with Database");





?>