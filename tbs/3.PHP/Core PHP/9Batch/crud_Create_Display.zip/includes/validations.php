<?php 
function validate_add()
{
	$errors = array();
	if(empty($_POST['name']))
	{
		$errors['name'] = "Please Enter Name";
	}
	elseif(!preg_match("#^[-A-Za-z' ]*$#",$_POST['name']))
		$errors['name'] = "Please enter valid name";
		
	/*if(empty($_POST['email_address']))
	{
		$errors['email_address'] = "Please Enter Email Address";
	}
	elseif(!filter_var($_POST['email_address'],FILTER_VALIDATE_EMAIL))
	{
		$errors['email_address'] = "Please Enter Email Address";
		
	}*/
	
	if(empty($_POST['address']))
	{
		$errors['address'] = "Please Enter Address";
	}
	if(empty($_POST['gender']))
	{
		$errors['gender'] = "Please Select Gender";
	}
	if(empty($_POST['hobbies']))
	{
		$errors['hobbies'] = "Please Select Hobbies";
	}
	if(empty($_POST['city_id']))
	{
		$errors['city_id'] = "Please Select City";
	}
	if($_FILES['avatar']['error']==4)
	{
		$errors['avatar'] = "Please Select Avatar";
	}
	return $errors;
	
	
}




?>