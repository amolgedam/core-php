<?php 
require_once("includes/config.php");
require_once("includes/validations.php");
if(isset($_POST['save']))
{
	/*print_r($_POST);
	print_r($_FILES);
	exit();*/
	$errors = array();
	$errors = validate_add();
	//print_r($errors);exit;
	if(!count($errors))
	{
		$no = rand();
		if($_FILES['avatar']['error']==0)
		{
			$src = $_FILES['avatar']['tmp_name'];
			$dest = "images/avatar/".$no."_".$_FILES['avatar']['name'];
			if(move_uploaded_file($src,$dest))
			{
				$_POST['avatar'] = $no."_".$_FILES['avatar']['name'];
			}
			$_POST['hobbies'] = implode(", ",$_POST['hobbies']);
			
			$insert = "insert into users set 
			name='".$_POST['name']."',
			address = '".$_POST['address']."',
			gender = '".$_POST['gender']."',
			hobbies = '".$_POST['hobbies']."',
			city_id = '".$_POST['city_id']."',
			avatar = '".$_POST['avatar']."',
			created = Now()";
			
			if(mysql_query($insert))
			{
				echo "Save Success";
				unset($_POST);
			}
			else
			{
				echo "Fail to Save";
				$_POST['hobbies'] = explode(", ",$_POST['hobbies']);
			}
			
		}
	}
	
	
}
$getcity = mysql_query("select * from cities");
?>



<!DOCTYPE HTML>
<html>
	<head>
		<title>ADD RECORDS</title>
		<style>
			.error
			{
				background-color:red;
				color:#fff;
				padding:2px;
			}
		</style>
	</head>
	<body>
		<form method="post" enctype="multipart/form-data">
		<table cellpadding="10px" cellspacing="0px" width="450px" align="center" border="1">
			<!--<tr>
				<td colspan="2" style="color:red;">
					<?php //echo implode("<br>",$errors);?>
				</td>
			</tr>-->
			<tr>
				<td><label>Name :</label></td>
				<td><input type="text" name="name" value="<?php echo isset($_POST['name'])?$_POST['name']:''; ?>"/>
					<?php if(isset($errors['name'])){?>
					<div class="error">
						<?php echo $errors['name'];?>
					</div>
					<?php } ?>
				
				</td>
			</tr>
			
			<tr>
				<td valign="top"><label>Address :</label></td>
				<td>
				<textarea rows="5" col="30" name="address"><?php echo isset($_POST['address'])?$_POST['address']:''; ?></textarea>
				<?php if(isset($errors['address'])){?>
					<div class="error">
						<?php echo $errors['address'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
			<tr>
				<td><label>Gender :</label></td>
				<td>
					<input type="radio" name="gender" value="male" <?php echo (isset($_POST['gender']) && $_POST['gender']=='male')?'checked':''?>/>Male
					<input type="radio" name="gender" value="female" <?php echo (isset($_POST['gender']) && $_POST['gender']=='female')?'checked':''?>/>Female
					<?php if(isset($errors['gender'])){?>
					<div class="error">
						<?php echo $errors['gender'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
			<tr>
				<td><label>Hobbies :</label></td>
				<td>
					<input type="checkbox" name="hobbies[]" value="reading" <?php echo isset($_POST['hobbies'])&& in_array("reading",$_POST['hobbies'])?'checked':'';  ?>/>Reading
					<input type="checkbox" name="hobbies[]" value="singing" <?php echo isset($_POST['hobbies'])&& in_array("singing",$_POST['hobbies'])?'checked':'';  ?>/>Singing
					<?php if(isset($errors['hobbies'])){?>
					<div class="error">
						<?php echo $errors['hobbies'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
			<tr>
				<td valign="top"><label>City :</label></td>
				<td>
					<select name="city_id">
						<option value="0" >-- Select City --</option>
						<?php while($cityrows = mysql_fetch_array($getcity)){
							?>
						<option value="<?php echo $cityrows['id'];?>" <?php echo isset($_POST['city_id']) && $_POST['city_id']==$cityrows['id']?'selected':'';?>><?php echo $cityrows['name'];?></option>
						<?php } ?>	
						</select>
						<?php if(isset($errors['city_id'])){?>
					<div class="error">
						<?php echo $errors['city_id'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
			
			<tr>
				<td><label>Avatar :</label></td>
				<td><input type="file" name="avatar" />
				<?php if(isset($errors['avatar'])){?>
					<div class="error">
						<?php echo $errors['avatar'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
				<tr>
				<td></td>
				<td>
					<input type="submit" name="save" value="SAVE"/>
					<input type="reset" name="reset"/>
					<input type="button" name="show" value="Display Data" onclick="window.location='show.php'"/>
				</td>
			</tr>
		</table>
		</form>
	</body>
</html>