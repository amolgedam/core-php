<?php 
require_once("includes/config.php");
if(isset($_GET['id']))
{
$sql = mysql_fetch_assoc(mysql_query("select * from users where id=".$_GET['id']));
//print_r($sql);
}
else
{
	header("location:show.php");
}
?>
<html>
	<head>
		<title>Display User Details</title>
	</head>
	<body>
		<table cellpadding="5px" cellspacing="0px" width="90%" border="1" align="center">
			<tr>
				<th>Sr No </th>
				<td><?php echo $sql['id'];?></td>
			</tr>
			<tr>
				<th>Name</th>
				<td><?php echo $sql['name'];?></td>
			</tr>
			<tr>
				<th>Address</th>
				<td><?php echo $sql['address'];?></td>
			</tr>
			<tr>
				<th>Gender</th>
				<td><?php echo $sql['gender'];?></td>
			</tr>
			<tr>
				<th>Hobbies</th>
				<td><?php echo $sql['hobbies'];?></td>
			</tr>
			<tr>
				<th>City</th>
				<td><?php 
				$getcity = mysql_fetch_assoc(mysql_query("select id,name from cities where id='".$sql['city_id']."'"));
				
				echo $getcity['name'];?></td>
			</tr>
			<tr>
				<th>Avatar</th>
				<td><img src="images/avatar/<?php echo $sql['avatar']?>" alt="avatar"/></td>
			</tr>
			<tr>
				<th></th>
				<td><input type="button" name="back" value="Back" onclick="window.location='show.php'"/></td>
			</tr>
		</table>
	
	</body>
</html>