<?php 
require_once("includes/config.php");
if(!isset($_SESSION['auth']['id']))
{
	header("location:index.php");
}
?>
<h1>Welcome <?php echo $_SESSION['auth']['name'];?></h1>
<a href="logout.php">Logout</a>