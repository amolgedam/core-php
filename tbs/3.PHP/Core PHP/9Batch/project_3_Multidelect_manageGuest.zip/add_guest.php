<?php 
require_once("includes/config.php");
if(!isset($_SESSION['auth']['id']))
{
	header("location:index.php");
}
if(isset($_POST['save']))
{
	/*print_r($_POST);
	print_r($_FILES);
	exit;*/
	$errors = array();
	$errors = validate_add();
	
}

$getcity = mysql_query("select * from cities");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Add Guests</title>
		<link href="css/style.css" rel="stylesheet"/>
	</head>
	<body>
		<div id="container">
		<?php require_once("includes/header.php"); ?>
		<?php require_once("includes/nav.php"); ?>
		<br/>
		<form method="post" enctype="multipart/form-data">
		<table cellpadding="10px" cellspacing="0px" width="450px" align="center" border="1">
			<!--<tr>
				<td colspan="2" style="color:red;">
					<?php //echo implode("<br>",$errors);?>
				</td>
			</tr>-->
			<tr>
				<td><label>Name :</label></td>
				<td><input type="text" name="name" value="<?php echo isset($_POST['name'])?$_POST['name']:''; ?>"/>
					<?php if(isset($errors['name'])){?>
					<div class="error">
						<?php echo $errors['name'];?>
					</div>
					<?php } ?>
				
				</td>
			</tr>
			<tr>
				<td><label>Email :</label></td>
				<td><input type="email" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:''; ?>"/>
					<?php if(isset($errors['email'])){?>
					<div class="error">
						<?php echo $errors['email'];?>
					</div>
					<?php } ?>
				
				</td>
			</tr>
			<tr>
				<td valign="top"><label>Address :</label></td>
				<td>
				<textarea rows="5" col="30" name="address"><?php echo isset($_POST['address'])?$_POST['address']:''; ?></textarea>
				<?php if(isset($errors['address'])){?>
					<div class="error">
						<?php echo $errors['address'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
			<tr>
				<td valign="top"><label>City :</label></td>
				<td>
					<select name="city_id">
						<option value="0" >-- Select City --</option>
						<?php while($cityrows = mysql_fetch_array($getcity)){
							?>
						<option value="<?php echo $cityrows['id'];?>" <?php echo isset($_POST['city_id']) && $_POST['city_id']==$cityrows['id']?'selected':'';?>><?php echo $cityrows['name'];?></option>
						<?php } ?>	
						</select>
						<?php if(isset($errors['city_id'])){?>
					<div class="error">
						<?php echo $errors['city_id'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
			<tr>
				<td><label>Phone :</label></td>
				<td>
					<input type="text" name="phone" value="<?php echo isset($_POST['phone'])?$_POST['phone']:''?>"/>
					<?php if(isset($errors['phone'])){?>
					<div class="error">
						<?php echo $errors['phone'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
			<tr>
				<td><label>Gender :</label></td>
				<td>
					<input type="radio" name="gender" value="male" <?php echo (isset($_POST['gender']) && $_POST['gender']=='male')?'checked':''?>/>Male
					<input type="radio" name="gender" value="female" <?php echo (isset($_POST['gender']) && $_POST['gender']=='female')?'checked':''?>/>Female
					<?php if(isset($errors['gender'])){?>
					<div class="error">
						<?php echo $errors['gender'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
			<tr>
				<td><label>Hobbies :</label></td>
				<td>
					<input type="checkbox" name="hobbies[]" value="reading" <?php echo isset($_POST['hobbies'])&& in_array("reading",$_POST['hobbies'])?'checked':'';  ?>/>Reading
					<input type="checkbox" name="hobbies[]" value="singing" <?php echo isset($_POST['hobbies'])&& in_array("singing",$_POST['hobbies'])?'checked':'';  ?>/>Singing
					<?php if(isset($errors['hobbies'])){?>
					<div class="error">
						<?php echo $errors['hobbies'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
			
			
			<tr>
				<td><label>Avatar :</label></td>
				<td><input type="file" name="avatar" />
				<?php if(isset($errors['avatar'])){?>
					<div class="error">
						<?php echo $errors['avatar'];?>
					</div>
					<?php } ?>
				</td>
			</tr>
				<tr>
				<td></td>
				<td>
					<input type="submit" name="save" value="SAVE"/>
					<input type="button" name="show" value="Back" onclick="window.location='manage_guests.php'"/>
				</td>
			</tr>
		</table>
		</form>
		<?php require_once("includes/footer.php"); ?>
		</div>
	</body>
</html>