<?php 
function validate_signup()
{
	$errors = array();
	if(empty($_POST['name']))
	{
		$errors['name'] = "Please Enter Name";
	}
	elseif(!preg_match("#^[-A-Za-z' ]*$#",$_POST['name']))
		$errors['name'] = "Please enter valid name";
		
	if(empty($_POST['email']))
	{
		$errors['email'] = "Please Enter Email Address";
	}
	elseif(!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))
	{
		$errors['email'] = "Please Enter Email Address";
	}
	if(empty($_POST['password']))
	{
		$errors['password'] = "Please Enter Password";
	}
	return $errors;
}	
function validate_add()
{
	$errors = array();
	if(empty($_POST['name']))
	{
		$errors['name'] = "Please Enter Name";
	}
	elseif(!preg_match("#^[-A-Za-z' ]*$#",$_POST['name']))
		$errors['name'] = "Please enter valid name";
		
	if(empty($_POST['email']))
	{
		$errors['email'] = "Please Enter Email Address";
	}
	elseif(!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))
	{
		$errors['email'] = "Please Enter Email Address";
		
	}
	if($_POST['city_id']==0)
	{
		$errors['city_id'] = "Please Select City";
	}
	if(empty($_POST['phone']))
	{
		$errors['phone'] = "Please Enter Phone";
	}
	elseif(!preg_match("#^[0-9]*$#",$_POST['phone']))
		$errors['phone'] = "Please enter valid Phone";
	if(empty($_POST['address']))
	{
		$errors['address'] = "Please Enter Address";
	}
	if(empty($_POST['gender']))
	{
		$errors['gender'] = "Please Select Gender";
	}
	if(empty($_POST['hobbies']))
	{
		$errors['hobbies'] = "Please Select Hobbies";
	}
	
	if($_FILES['avatar']['error']==4)
	{
		$errors['avatar'] = "Please Select Avatar";
	}
	return $errors;
}
	


?>