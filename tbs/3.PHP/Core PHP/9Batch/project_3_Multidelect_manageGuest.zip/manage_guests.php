<?php 
require_once("includes/config.php");
if(!isset($_SESSION['auth']['id']))
{
	header("location:index.php");
}
if(isset($_POST['multidelete']))
{
	$ID = $_POST['selector'];
	$noofrec = count($ID);
	//print_r($noofrec);exit;
	for($i =0;$i<$noofrec; $i++)
	{
		mysql_query("delete from guests where id='".$ID[$i]."'");
	}
	$msg = "Records Deleted";
	
}


$sql = mysql_query("select * from guests");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Manage Guests</title>
		<link href="css/style.css" rel="stylesheet"/>
	</head>
	<body>
		<div id="container">
		<?php require_once("includes/header.php"); ?>
		<?php require_once("includes/nav.php"); ?>
		<br/>
		<form method="post" onsubmit="return confirm('Delete ?');">
		<table cellpadding="10px" cellspacing="0px" width="90%" align="center" border="1">
			<?php if(isset($msg)){?>
			<tr>
				<td colspan="5">
				<?php echo $msg;?>
				</td>
			</tr>
			<?php } ?>
			<tr>
				<td colspan="5" style="text-align:right;">
					<input type="button" name="add" value="Add New" onclick="window.location='add_guest.php'"/>
				</td>
			</tr>
			<tr>
				<th>#</th>
				<th>Sr No</th>
				<th>Name</th>
				<th>Email</th>
				<th>Action</th>
				
			</tr>
			<?php 
			$sr = 1;
			while($rows = mysql_fetch_array($sql)){ ?>
			<tr>
				<td><input type="checkbox" name="selector[]" value="<?php echo $rows['id'];?>" /></td>
				<td><?php echo $sr;?></td>
				<td><?php echo $rows['name'];?></td>
				<td><?php echo $rows['email'];?></td>
				<td>Show | Edit | Delete</td>
				
				</tr>
			<?php $sr++;} ?>
				<tr>
					<td colspan="7">
						<button type="submit" name="multidelete">Delete</button>
					</td>
				</tr>			
		</table>
		</form>
		<?php require_once("includes/footer.php"); ?>
		</div>
	</body>
</html>