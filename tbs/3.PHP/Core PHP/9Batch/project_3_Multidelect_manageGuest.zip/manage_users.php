<?php 
require_once("includes/config.php");
if(!isset($_SESSION['auth']['id']))
{
	header("location:index.php");
}
if(isset($_POST['multidelete']))
{
	$ID = $_POST['selector'];
	$noofrec = count($ID);
	//print_r($noofrec);exit;
	for($i =0;$i<$noofrec; $i++)
	{
		mysql_query("delete from users where id='".$ID[$i]."'");
	}
	$msg = "Records Deleted";
	
}


$sql = mysql_query("select * from users where role='user'");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Manage Users</title>
		<link href="css/style.css" rel="stylesheet"/>
	</head>
	<body>
		<div id="container">
		<?php require_once("includes/header.php"); ?>
		<?php require_once("includes/nav.php"); ?>
		<br/>
		<form method="post" onsubmit="return confirm('Delete ?');">
		<table cellpadding="10px" cellspacing="0px" width="90%" align="center" border="1">
			<?php if(isset($msg)){?>
			<tr>
				<td colspan="7">
				<?php echo $msg;?>
				</td>
			</tr>
			<?php } ?>
			<tr>
				<th>#</th>
				<th>Sr No</th>
				<th>Name</th>
				<th>Email</th>
				<th>Last Login</th>
				<th>Last IP</th>
				<th>Status</th>	
			</tr>
			<?php 
			$sr = 1;
			while($rows = mysql_fetch_array($sql)){ ?>
			<tr>
				<td><input type="checkbox" name="selector[]" value="<?php echo $rows['id'];?>" /></td>
				<td><?php echo $sr;?></td>
				<td><?php echo $rows['name'];?></td>
				<td><?php echo $rows['email'];?></td>
				<td><?php echo $rows['lastlogin'];?></td>
				<td><?php echo $rows['lastip'];?></td>
				<td><?php
					if($rows['status']=='inactive')
					{?>
						<a href="change.php?id=<?php echo $rows['id'];?>&s=i" onclick="return confirm('change status?');"><img src="images/cross.png" alt="Inactive" /></a>
					<?php }
					else
					{ ?>
						<a href="change.php?id=<?php echo $rows['id'];?>&s=a" onclick="return confirm('change status?');"><img src="images/tick.png" alt="Active"/></a>
					<?php }	?></td>
				</tr>
			<?php $sr++;} ?>
				<tr>
					<td colspan="7">
						<button type="submit" name="multidelete">Delete</button>
					</td>
				</tr>			
		</table>
		</form>
		<?php require_once("includes/footer.php"); ?>
		</div>
	</body>
</html>