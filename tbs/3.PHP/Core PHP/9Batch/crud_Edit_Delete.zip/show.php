<?php 
require_once("includes/config.php");
$sql = mysql_query("select * from users");
?>
<html>
	<head>
		<title>Display Details</title>
	</head>
	<body>
		<table cellpadding="5px" cellspacing="0px" width="90%" border="1" align="center">
			<tr>
				<th>Sr No </th>
				<th>Name </th>
				<th>Address</th>
				<th>Avatar</th>
				<th>Action</td>
			</tr>
			<?php 
			$no = 1;
			while($rows = mysql_fetch_array($sql)){?>
			<tr>
				<td><?php echo $no;?></td>
				<td><?php echo $rows['name'];?> </td>
				<td><?php echo $rows['address'];?></td>
				<td>
				<img src="images/avatar/<?php echo $rows['avatar'];?>" alt="avatar" width="50px" height="50px"/>
				
				</td>
				<td><a href="showdata.php?id=<?php echo $rows['id'];?>">Show</a> | 
				<a href="edit.php?id=<?php echo $rows['id'];?>">Edit</a> | 
				<a href="delete.php?id=<?php echo $rows['id'];?>">Delete</a></td>
			</tr>
			<?php $no++;} ?>
		</table>
	
	</body>
</html>