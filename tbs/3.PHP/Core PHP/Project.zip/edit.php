<?php
require_once("includes/config.php");

if(isset($_POST['update']))
{
	$errors = array();
	$errors = validate_signup_edit();
	if(!count($errors))
	{
		$selectdata = mysql_query("select id,email from users where email='".$_POST['email']."'");
		if(mysql_num_rows($selectdata))
		{
			$rslt = "Email Aready Exist";
		}
		else
		{
			$update = "Update users set 
			name='".$_POST['name']."',
			email='".$_POST['email']."',
			modified = Now()
			where id='".$_GET['id']."'";
			if(mysql_query($update))
			{
				header("location:users.php");
			}
			else
			{
				$rslt = "Update Fail";
			}
		}
	}
}






$_POST = mysql_fetch_assoc(mysql_query("select id,name,email from users where id='".$_GET['id']."'"));

//print_r($select);exit;

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Guestbook</title>
	<?php require_once("includes/head.php")?>
</head>
<body>
  <div id="container">
    <div id="header">
      <h1><a href="index.html">Guestbook</a></h1>
    </div>
    <div id="wrapper" class="wat-cf">
    <div id="box">
      <div class="block" id="block-signup">
        <h2>Edit Details</h2>
        <?php if(isset($rslt)){ ?>
		<div class="flash">
            <div class="message notice">
              <p><?php echo $rslt; ?></p>
            </div>
          </div>
		<?php } ?>
		<div class="content">
          <form method="post" class="form">
            <div class="group wat-cf">
              <div class="left">
                <label class="label">Name</label>
              </div>
              <div class="right">
                <input type="text" class="text_field" name="name" value="<?php echo isset($_POST['name'])?$_POST['name']:''; ?>"/>
                <span class="description">Ex: Vaibhav Deshpande</span>
		        <?php if(isset($errors['name'])){?>
				<div class="error">
					<?php echo $errors['name'];?>
				</div>
				<?php } ?>
              </div>
            </div>
            <div class="group wat-cf">
              <div class="left">
                <label class="label">Email</label>
              </div>
              <div class="right">
                <input type="text" class="text_field" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:''; ?>"/>
                <span class="description">Ex: test@example.com</span>
		<?php if(isset($errors['email'])){?>
				<div class="error">
					<?php echo $errors['email'];?>
				</div>
				<?php } ?>
              </div>
            </div>
            
            <div class="group navform wat-cf">
              <button class="button" type="submit" name="update">
                <img src="images/icons/tick.png" alt="Save" /> Update
              </button>
			  <button class="button" type="submit" onclick="window.location='users.php';">
                <img src="images/icons/tick.png" alt="Save" /> View All Details
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
</html>