<?php 
require_once("includes/config.php");
if(isset($_GET['id']))
{
	//$users = mysql_fetch_assoc(mysql_query("Select email from users where id='".$_GET['id']."'"));
	//print_r($users['email']);exit;
	
	$delete = "delete from users where id='".$_GET['id']."'";
	if(mysql_query($delete))
	{
		header("location:users.php");
		//unlink("images/avatar/".$users['email']);
	}
	else
	{
		echo "delete Fail";
	}
	
}
else
{
	header("location:users.php");
}



?>