<?php 
require_once("includes/config.php");
$sql = mysql_query("select * from users");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Guestbook</title>
  <link rel="stylesheet" href="css/base.css" type="text/css" media="screen" />
  <link rel="stylesheet" id="current-theme" href="css/bec/style.css" type="text/css" media="screen" />  
</head>
<body>
   <div id="container">
	 <div id="header">
      <h1><a href="index.html">Guestbook</a></h1>
    </div>
    <div id="wrapper" class="wat-cf">
      <div id="main">
	
 	<div class="inner">
              <div class="flash">
                <div class="message notice">
                  <p>Notice message</p>
                </div>
              </div>
       </div>
        

        <div class="block" id="block-tables">
          <div class="secondary-navigation"></div>
          <div class="content">
            <h2 class="title">Users</h2>
	    <div class="actions-bar wat-cf">
                  
            </div>

            <div class="inner">
              <form action="#" class="form">
                <table class="table">
                  <tr>
                    <th class="first"><input type="checkbox" class="checkbox toggle" /></th>
                    <th>Sr. No.</th>
                    <th>Name</th>
                    <th>Email Id</th>
                    <th class="last">&nbsp;</th>
                  </tr>
                  <?php while($rows = mysql_fetch_array($sql)){?>
				  <tr class="odd">
                    <td><input type="checkbox" class="checkbox" name="id" value="1" /></td>
					<td><?php echo $rows['id']; ?></td>
					<td><?php echo $rows['name']; ?></td>
					<td><?php echo $rows['email']; ?></td>
					<td class="last">
					<a href="edit.php?id=<?php echo $rows['id']; ?>">edit</a> | 
					<a href="delete.php?id=<?php echo $rows['id']; ?>" onclick="return confirm('Delete?')">destroy</a></td>
                  </tr>
				  <?php } ?>
                </table>
                <div class="actions-bar wat-cf">
                  <div class="actions">
                    <button class="button" type="submit">
                      <img src="images/icons/cross.png" alt="Delete" /> Delete
                    </button>
                  </div>
                  <div class="pagination">
                    <span class="disabled prev_page">« Previous</span><span class="current">1</span><a rel="next" href="#">2</a><a href="#">3</a><a href="#">4</a><a href="#">5</a><a href="#">6</a><a href="#">7</a><a href="#">8</a><a href="#">9</a><a href="#">10</a><a href="#">11</a><a rel="next" class="next_page" href="#">Next »</a>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

       

       
        <div id="footer">
          <div class="block">
            <p>Copyright &copy; 2010 Your Site.</p>
          </div>
        </div>
      </div>
      
     <div id="sidebar">       
        <div class="block notice">
          <h4>Notice Title</h4>
          <p>Morbi posuere urna vitae nunc. Curabitur ultrices, lorem ac aliquam blandit, lectus eros hendrerit eros, at eleifend libero ipsum hendrerit urna. Suspendisse viverra. Morbi ut magna. Praesent id ipsum. Sed feugiat ipsum ut felis. Fusce vitae nibh sed risus commodo pulvinar. Duis ut dolor. Cras ac erat pulvinar tortor porta sodales. Aenean tempor venenatis dolor.</p>
        </div>        
      </div>

    </div>
    
  </div>

</body>
</html>

