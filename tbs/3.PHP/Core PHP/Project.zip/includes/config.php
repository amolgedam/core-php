<?php
// Connection with server
$conn = mysql_connect("localhost","root","") or die("could not connect to server");

//Database Selection
mysql_select_db("batch_22_guestbook",$conn) or die("could not select Database");

require_once("includes/validations.php");
 ?>