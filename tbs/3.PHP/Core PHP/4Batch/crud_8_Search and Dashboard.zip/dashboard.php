<?php 
require_once("includes/config.php");
if(!isset($_SESSION['auth']['id']))
{
	header("location:index.php");
}
$totusers = mysql_num_rows(mysql_query("select * from users where role!='admin'"));
$totusersa = mysql_num_rows(mysql_query("select * from users where role!='admin' and status='active'"));
$totusersi =  mysql_num_rows(mysql_query("select * from users where  role!='admin' and status='inactive'"));

$totf = mysql_num_rows(mysql_query("select * from friends where user_id='".$_SESSION['auth']['id']."'"));
$totfm = mysql_num_rows(mysql_query("select * from friends where user_id='".$_SESSION['auth']['id']."' and gender='male'"));
$totff =  mysql_num_rows(mysql_query("select * from friends where user_id='".$_SESSION['auth']['id']."' and gender='female'"));


$users = mysql_query("select * from users where role!='admin' order by id desc limit 0,3");
$friendsm = mysql_query("select * from friends where user_id='".$_SESSION['auth']['id']."' and gender='male' order by id desc limit 0,3");
$friendsf = mysql_query("select * from friends where user_id='".$_SESSION['auth']['id']."' and gender='female' order by id desc limit 0,3");

?>

<html>
	<head>
		<title>Dashboard</title>
		<link href="css/style.css" rel="stylesheet"/>
	</head>
	<body>
		<h1>SLAMBOOK - DASHBOARD</h1>
		<?php require_once("includes/nav.php");?>	
		<table cellpadding="10px" cellspacing="0px" width="90%" align="center" border="0">
			<?php if($_SESSION['auth']['role']=='admin'){?>
			<tr>
			<td valign="top">
				<table cellpadding="10px" cellspacing="0px" width="100%" align="center" border="1">
					<tr>
						<td bgcolor="#ccc" colspan="2">Total Users Details</td>
					</tr>
					<tr>
						<td>Total Users : </td>
						<td><a href="#"><?php echo $totusers;?></a></td>
					</tr>
					<tr>
						<td>Total Active Users : <a href="#"><?php echo $totusersa;?></a></td>
						
						<td>Total Inactive Users : <a href="#"><?php echo $totusersi;?></a></td>
						
					</tr>
				</table>
			</td>
			<td>&nbsp;</td>
			<td valign="top">
				<table cellpadding="5px" cellspacing="0px" width="100%" align="center" border="1">
					<tr>
						<td bgcolor="#ccc" colspan="3">Recent 3 Users</td>
					</tr>
					<?php $sr = 1;
					while($rowusers = mysql_fetch_array($users)){?>
					<tr>
						<td><?php echo $sr;?></td>
						<td><?php echo $rowusers['name']; ?></td>
						<td><?php echo $rowusers['email_address']; ?></td>
					</tr>
					<?php $sr++; } ?>
				</table>
				
			</td>
		</tr>
			<?php } ?>
		<tr>
			<td valign="top">
				<table cellpadding="10px" cellspacing="0px" width="100%" align="center" border="1">
					<tr>
						<td bgcolor="#ccc" colspan="2">Total Friends Details</td>
					</tr>
					<tr>
						<td>Total Friends : </td>
						<td><a href="#"><?php echo $totf;?></a></td>
					</tr>
					<tr>
						<td>Total Male Friends : <a href="#"><?php echo $totfm;?></a></td>
						
						<td>Total Female Friends : <a href="#"><?php echo $totff;?></a></td>
						
					</tr>
				</table>			
			</td>
			<td>&nbsp;</td>
			<td valign="top">
				<table cellpadding="5px" cellspacing="0px" width="100%" align="center" border="1">
					<tr>
						<td bgcolor="#ccc" colspan="3">Recent 3 Male &amp; Female Friends</td>
					</tr>
					<?php $sr = 1;
					while($rowfriendsm = mysql_fetch_array($friendsm)){?>
					<tr>
						<td><?php echo $sr;?></td>
						<td><?php echo $rowfriendsm['name']; ?></td>
						<td><?php echo $rowfriendsm['gender']; ?></td>
					</tr>
					<?php $sr++; } ?>
					<?php 
					while($rowfriendsf = mysql_fetch_array($friendsf)){?>
					<tr>
						<td><?php echo $sr;?></td>
						<td><?php echo $rowfriendsf['name']; ?></td>
						<td><?php echo $rowfriendsf['gender']; ?></td>
					</tr>
					<?php $sr++; } ?>
				</table>
			</td>
		</tr>
	</table>	
		
		
		<h6>&copy; Copyright 2016. All Rights Reserved</h6>	
	</body>
</html>