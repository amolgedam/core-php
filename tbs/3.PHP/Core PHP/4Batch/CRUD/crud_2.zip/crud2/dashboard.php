<?php 
require_once("includes/config.php");
if(!isset($_SESSION['auth']['id']))
{
	header("location:index.php");
}
?>

<html>
	<head>
		<title>Dashboard</title>
		<link href="css/style.css" rel="stylesheet"/>
	</head>
	<body>
		<h1>SLAMBOOK - DASHBOARD</h1>
		<p style="text-align:left; border:2px solid green;padding:5px 20px;">Welcome <?php echo $_SESSION['auth']['name'];?> [ <a href="logout.php">Logout</a> ] </p>
		
		
		<h6>&copy; Copyright 2016. All Rights Reserved</h6>	
	</body>
</html>