<?php 
require_once("includes/config.php");
if(!isset($_SESSION['auth']['id']))
{
	header("location:index.php");
}

	$select = mysql_query("select * from friends where user_id='".$_SESSION['auth']['id']."'");
	
?>

<html>
	<head>
		<title>Manage Friends</title>
		<link href="css/style.css" rel="stylesheet"/>
	</head>
	<body>
		<h1>SLAMBOOK - FRIENDS</h1>
		<?php require_once("includes/nav.php");?>
		<table cellpadding="5px" cellspacing="0px" width="90%" border="1" align="center">
			<tr>
				<td colspan="7" style="text-align:right;">
					<button type="button" onclick="window.location='addfriend.php'">ADD FRIENDS</button>
				</td>
			</tr>
			<tr>
				<th></th>
				<th>Sr No</th>
				<th>Name</th>
				<th>Address</th>
				<th>City</th>
				<th>Avatar</th>
				<th>Action</th>
			</tr>
			<?php 
			$sr = 1;
			while($rows = mysql_fetch_array($select)){ ?>
			<tr>
				<td><input type="checkbox" /></td>
				<td><?php echo $sr;?></td>
				<td><?php echo $rows['name'];?></td>
				<td><?php echo $rows['address'];?></td>
				<td><?php 
				$getcity = mysql_fetch_assoc(mysql_query("select * from cities where id='".$rows['city_id']."'"));
				echo $getcity['name']; ?></td>
				<td><img src="images/avatar/<?php echo $rows['avatar'];?>" alt="avatar" width="50px"/></td>
				<td>
				<a href="show_friends.php?id=<?php echo $rows['id'];?>">Show</a> | 
				<a href="edit_friends.php?id=<?php echo $rows['id'];?>">Edit</a> | 
				<a href="delete_friends.php?id=<?php echo $rows['id'];?>" onclick="return confirm('delete?');">Delete</a></td>
			</tr>
			<?php $sr++;} ?>
		</table>
		
		<h6>&copy; Copyright 2016. All Rights Reserved</h6>	
	</body>
</html>