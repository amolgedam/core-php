<?php
require_once("includes/config.php");
if(!isset($_SESSION['auth']['id']))
{
	header("location:index.php");
	exit;
}
else
{
	unset($_SESSION['auth']);
	header("location:index.php");
	exit;
}

?>