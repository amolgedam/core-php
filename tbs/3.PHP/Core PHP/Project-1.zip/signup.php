<?php
require_once("includes/config.php");
require_once("includes/validations.php");
if(isset($_POST['save']))
{
	//print_r($_POST);exit;
	$errors = validate_signup();
	//print_r($errors);//exit;
	if(!count($errors))
	{
		$sql = mysql_query("select * from users where email='".$_POST['email']."'");
		$countrec = mysql_num_rows($sql);
		if($countrec==1)
		{
			$rslt = "email already exist";
		}
		else
		{
			$insert = "insert into users set 
			name='".$_POST['name']."',
			email='".$_POST['email']."',
			password=md5('".$_POST['password']."'),
			created=Now()";
			if(mysql_query($insert))
			{
				header("location:signup_success.php");
			}
			else
			{
				$rslt = "Register Fail";
			}
		}
	}
	
}

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Guestbook</title>
	<?php require_once("includes/head.php")?>
</head>
<body>
  <div id="container">
    <div id="header">
      <h1><a href="index.html">Guestbook</a></h1>
    </div>
    <div id="wrapper" class="wat-cf">
    <div id="box">
      <div class="block" id="block-signup">
        <h2>Sign up</h2>
        <?php if(isset($rslt)){ ?>
		<div class="flash">
            <div class="message notice">
              <p><?php echo $rslt; ?></p>
            </div>
          </div>
		<?php } ?>
		<div class="content">
          <form method="post" class="form">
            <div class="group wat-cf">
              <div class="left">
                <label class="label">Name</label>
              </div>
              <div class="right">
                <input type="text" class="text_field" name="name" value="<?php echo isset($_POST['name'])?$_POST['name']:''; ?>"/>
                <span class="description">Ex: Vaibhav Deshpande</span>
		        <?php if(isset($errors['name'])){?>
				<div class="error">
					<?php echo $errors['name'];?>
				</div>
				<?php } ?>
              </div>
            </div>
            <div class="group wat-cf">
              <div class="left">
                <label class="label">Email</label>
              </div>
              <div class="right">
                <input type="text" class="text_field" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:''; ?>"/>
                <span class="description">Ex: test@example.com</span>
		<?php if(isset($errors['email'])){?>
				<div class="error">
					<?php echo $errors['email'];?>
				</div>
				<?php } ?>
              </div>
            </div>
            <div class="group wat-cf">
              <div class="left">
                <label class="label">Password</label>
              </div>
              <div class="right">
                <input type="password" class="text_field" name="password" />
                <span class="description">Must contains the word 'yeah'</span>
		<?php if(isset($errors['password'])){?>
				<div class="error">
					<?php echo $errors['password'];?>
				</div>
				<?php } ?>
              </div>
            </div>
            <div class="group navform wat-cf">
              <button class="button" type="submit" name="save">
                <img src="images/icons/tick.png" alt="Save" /> Signup
              </button>
			  <button class="button" type="submit" onclick="window.location='users.php';">
                <img src="images/icons/tick.png" alt="Save" /> View All Details
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
</html>