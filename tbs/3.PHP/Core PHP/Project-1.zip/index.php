<?php
require_once("includes/config.php");
require_once("includes/validations.php");
if(isset($_POST['save']))
{
	$errors = array();
	$errors=logerror();
	if(count($errors)==0)
	{
		$sql="select * from admins where email='".$_POST['email']."' and password= md5('".$_POST['password']."')";
		$res=mysql_query($sql);
		$result=mysql_fetch_assoc($res);
		if(isset($result['id']))
		{
			$_SESSION['auth']=$result;
			unset($_SESSION['auth']['password']);
			header("location:dashboard.php");
			}
		else
		{
			$rslt="u r not authorize";
		}
		
		
		//print_r($result);
		//exit;
	}
	
}


?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
	<title>Guestbook</title>
	<?php require_once("includes/head.php")?>
</head>
<body>
  <div id="container">
    <div id="header">
      <h1><a href="index.html">Guestbook</a></h1>
    </div>
    <div id="wrapper" class="wat-cf">
    <div id="box">
      <div class="block" id="block-signup">
        <h2>Login</h2>
        <?php if(isset($rslt)){ ?>
		<div class="flash">
            <div class="message notice">
              <p><?php echo $rslt; ?></p>
            </div>
          </div>
		<?php } ?>
		<div class="content">
          <form method="post" class="form">
            
            <div class="group wat-cf">
              <div class="left">
                <label class="label">Email</label>
              </div>
              <div class="right">
                <input type="email" class="text_field" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:''; ?>"/>
                <span class="description">Ex: test@example.com</span>
		<?php if(isset($errors['email'])){?>
				<div class="error">
					<?php echo $errors['email'];?>
				</div>
				<?php } ?>
              </div>
            </div>
            <div class="group wat-cf">
              <div class="left">
                <label class="label">Password</label>
              </div>
              <div class="right">
                <input type="password" class="text_field" name="password" />
                <span class="description">Must contains the word 'yeah'</span>
		<?php if(isset($errors['password'])){?>
				<div class="error">
					<?php echo $errors['password'];?>
				</div>
				<?php } ?>
              </div>
            </div>
            <div class="group navform wat-cf">
              <button class="button" type="submit" name="save">
                <img src="images/icons/tick.png" alt="Save" /> Login
              </button>
			  <button class="button" type="submit" onclick="window.location='users.php';">
                <img src="images/icons/tick.png" alt="Save" /> Forgot Password
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
</html>