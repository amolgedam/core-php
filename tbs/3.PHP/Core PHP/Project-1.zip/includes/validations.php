<?php 
function validate_signup()
{
	$errors = array();
	if(empty($_POST['name']))
	{
		$errors['name'] ="Please Enter Name";
	}
	if(empty($_POST['email']))
	{
		$errors['email'] = "Please Enter Email";
	}
	if(empty($_POST['password']))
	{
		$errors['password'] = "Please Enter Password";
	}
	return $errors;
	
}
function validate_signup_edit()
{
	$errors = array();
	if(empty($_POST['name']))
	{
		$errors['name'] ="Please Enter Name";
	}
	if(empty($_POST['email']))
	{
		$errors['email'] = "Please Enter Email";
	}
	
	return $errors;
	
}
function logerror()
{
	$errors=array();
	if(empty($_POST['email']))
	{
		$errors['email'] = "Please Enter Email";
	}
	if(empty($_POST['password']))
	{
		$errors['password'] = "Please Enter Password";
	}
	return $errors;
	}
	



?>