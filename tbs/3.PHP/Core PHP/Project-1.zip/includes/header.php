<div id="header">
      <h1><a href="index.html">Guestbook</a></h1>
      <div id="user-navigation">
        <ul class="wat-cf">
          <li><a href="#">Profile</a></li>
          <li><a href="#">Change Password</a></li>
          <li><a class="logout" href="logout.php">Logout</a></li>
        </ul>
      </div>
      <div id="main-navigation">
        <ul class="wat-cf">
          <li class="first"><a href="#block-text">Dashboard</a></li>
          <li class="active"><a href="guests.html">Guests</a></li>
        </ul>
      </div>
    </div>