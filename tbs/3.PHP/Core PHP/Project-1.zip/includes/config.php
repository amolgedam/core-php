<?php
// Connection with server
$conn = mysql_connect("localhost","root","") or die("could not connect to server");

//Database Selection
mysql_select_db("batch_22_guestbook",$conn) or die("could not select Database");

require_once("includes/validations.php");

// To Start the session
session_start();

//to assign name to session 
session_name("auth");





 ?>